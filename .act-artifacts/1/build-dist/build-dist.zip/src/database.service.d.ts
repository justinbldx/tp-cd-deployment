import { OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import Database from 'better-sqlite3';
export declare class DatabaseService implements OnModuleInit, OnModuleDestroy {
    private readonly logger;
    readonly db: Database.Database;
    constructor();
    onModuleInit(): void;
    onModuleDestroy(): void;
}
