"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TasksService = void 0;
const common_1 = require("@nestjs/common");
const database_service_1 = require("../database.service");
function toTask(row) {
    return {
        id: row.id,
        title: row.title,
        content: row.content ?? null,
        done: row.done === 1,
        createdAt: new Date(row.createdAt),
    };
}
let TasksService = class TasksService {
    db;
    constructor(db) {
        this.db = db;
    }
    create(createTaskDto) {
        const result = this.db.db
            .prepare('INSERT INTO task (title, content, done) VALUES (?, ?, ?)')
            .run(createTaskDto.title, createTaskDto.content ?? null, createTaskDto.done ? 1 : 0);
        return this.findOne(result.lastInsertRowid);
    }
    findAll() {
        const rows = this.db.db
            .prepare('SELECT * FROM task ORDER BY createdAt DESC')
            .all();
        return rows.map(toTask);
    }
    findOne(id) {
        const row = this.db.db
            .prepare('SELECT * FROM task WHERE id = ?')
            .get(id);
        if (!row) {
            throw new common_1.NotFoundException(`Tâche #${id} introuvable`);
        }
        return toTask(row);
    }
    update(id, updateTaskDto) {
        this.findOne(id);
        const sets = [];
        const values = [];
        if (updateTaskDto.title !== undefined) {
            sets.push('title = ?');
            values.push(updateTaskDto.title);
        }
        if (updateTaskDto.content !== undefined) {
            sets.push('content = ?');
            values.push(updateTaskDto.content);
        }
        if (updateTaskDto.done !== undefined) {
            sets.push('done = ?');
            values.push(updateTaskDto.done ? 1 : 0);
        }
        if (sets.length > 0) {
            values.push(id);
            this.db.db
                .prepare(`UPDATE task SET ${sets.join(', ')} WHERE id = ?`)
                .run(...values);
        }
        return this.findOne(id);
    }
    remove(id) {
        const task = this.findOne(id);
        this.db.db.prepare('DELETE FROM task WHERE id = ?').run(id);
        return task;
    }
};
exports.TasksService = TasksService;
exports.TasksService = TasksService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [database_service_1.DatabaseService])
], TasksService);
//# sourceMappingURL=tasks.service.js.map